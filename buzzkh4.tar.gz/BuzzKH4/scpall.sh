#!/bin/bash

file=$1

#scp $1 K01:$2
scp $1 K02:$2
scp $1 K03:$2
scp $1 K04:$2
scp $1 K05:$2
scp $1 K06:$2
scp $1 K07:$2
scp $1 K08:$2
scp $1 K09:$2
scp $1 K10:$2
