#!/bin/bash
scp bzzkh4 root@K02:/home/root/formation/
scp bzzkh4 root@K03:/home/root/formation/
scp bzzkh4 root@K04:/home/root/formation/
scp bzzkh4 root@K05:/home/root/formation/
scp bzzkh4 root@K06:/home/root/formation/
scp bzzkh4 root@K07:/home/root/formation/
scp bzzkh4 root@K08:/home/root/formation/
scp bzzkh4 root@K09:/home/root/formation/
scp bzzkh4 root@K10:/home/root/formation/


