#ifndef KH4_UTILITY_H
#define KH4_UTILITY_H

#include <khepera/khepera.h>

extern void kh4_setup();

extern void kh4_done();

extern knet_dev_t* DSPIC;

#endif
